## Group Identitfication
Group 57

## Project Manager Name
Christian Varriale

## Description of Contents
- code
- group.csv
- README.md
- p2_report.pdf
/*
 * kcd_task.h
 *
 *  Created on: Mar. 13, 2021
 *      Author: is2kang
 */

#ifndef SRC_APP_KCD_TASK_H_
#define SRC_APP_KCD_TASK_H_



#include "Serial.h"
#include "k_msg.h"
#include "rtx.h"


/*****************FUNCTION PROTOTYPE ******************/

void kcd_task(void);





#endif /* SRC_APP_KCD_TASK_H_ */
